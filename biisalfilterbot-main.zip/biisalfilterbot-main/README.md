<p align="center">
  <img src="https://graph.org/file/11192a1c4d6327b06f379.jpg">
</p>
<h1 align="center">
  Biisal Filter Bot
</h1>

First Check our **Demo** bot -

[![Click Here](https://img.shields.io/badge/Demo%20Bot-Click%20Here-blue?style=flat&logo=telegram&labelColor=white&link=https://t.me/iMdbChatRoom)](https://t.me/ipopcormbot)

### Need Deployment Support?

If you encounter any issues **Deploying** the bot, feel free to seek assistance in our **support group**:

[![Join Support Group    ](https://img.shields.io/badge/Join%20Support%20Group-Click%20Here-blue?style=flat&logo=telegram&labelColor=white&link=https://t.me/iMdbChatRoom)](https://t.me/iMdbChatRoom)

# About This Repository :

The bot repository is designed to filter and manage files on Telegram. It allows you to add files either automatically or manually. The bot can respond to users in groups or private chats by providing the files they search for, using shortened links set by the group admin or bot admin.
<br>
For more information of the project, please refer to the [FEATURES PAGE]

